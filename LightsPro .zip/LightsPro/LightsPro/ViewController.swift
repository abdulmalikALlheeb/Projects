//
//  ViewController.swift
//  LightsPro
//
//  Created by عبدالملك اللهيب on 07/07/1444 AH.
//

import UIKit

class ViewController: UIViewController {


    @IBOutlet weak var lightStatus: UIButton!
    var turnOn = true
    override func viewDidLoad() {
        super.viewDidLoad()
        chengelight()
    }
    func chengelight() {
        if turnOn{
            lightStatus.setTitle("ON", for: .normal)
            view.backgroundColor = .white
        }
        else{
            view.backgroundColor = .black
            lightStatus.setTitle("OFF", for: .normal)
        }
    }
    @IBAction func buttonPressed(_ sender: UIButton) {
        
        turnOn.toggle()
        chengelight()
    }
}

 


