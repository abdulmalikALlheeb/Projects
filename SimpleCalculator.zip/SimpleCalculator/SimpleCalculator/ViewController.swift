//
//  ViewController.swift
//  SimpleCalculator
//
//  Created by عبدالملك اللهيب on 10/07/1444 AH.
//



import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var height: UITextField!
    @IBOutlet weak var width: UITextField!
    @IBOutlet weak var result: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func calculateArea(_ sender: UIButton) {
        if let h = Double(height.text ?? "0"), let w = Double(width.text ?? "0") {
            result.text = String(h * w)
        } else {
            result.text = "Invalid Results"
        }
    }
    
    @IBAction func resetView(_ sender: UIButton) {
        height.text = ""
        width.text = ""
        result.text = ""
    }
    

}

