/*
See the License.txt file for this sample’s licensing information.
*/

import SwiftUI

struct ContactWithMe: View {

    @State private var funFact = ""
    var body: some View {
        VStack {
            Text("Contact With Me")
                .font(.largeTitle)
                .fontWeight(.bold)
                .position(x : 170 , y: 20)

                        
            
            Image(systemName: "envelope")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .position(x: 110,y: -60)
                .padding(70)
            
            
            Link("Feel free to send me an email", destination: URL(string: "https://abdulmalik.m4464@gmail.com")!
            )
                .padding()

            Text("Phone Number : 0552439505")
                .foregroundColor(Color.blue)
            
            
        }
        .padding()
    }
}

struct FunFactsView_Previews: PreviewProvider {
    static var previews: some View {
        ContactWithMe()
    }
}
