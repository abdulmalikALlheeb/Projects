/*
See the License.txt file for this sample’s licensing information.
*/

import SwiftUI
struct Skills: View {
    var body: some View {
        VStack {
            
            Text("SKILLS")
                .font(.largeTitle)
                .fontWeight(.bold)
                .padding(.bottom, 9)
            
            
            
            Image(information.image)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .cornerRadius(1000)
                .padding(10)
            
            ScrollView {
                Text(information.skils)
                    .font(.title)
                    .foregroundColor(Color(hue: 0.68, saturation: 0.948, brightness: 0.62))
                    .multilineTextAlignment(.leading)
                    .padding()
                    .position(x:110 , y: 110)
                   
                    
                    
                
                    
                
                
                
                
            }
        }
    }
    
    struct FavoritesView_Previews: PreviewProvider {
        static var previews: some View {
            Skills()
        }
    }
}
